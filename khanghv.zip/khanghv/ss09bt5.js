let vl = +prompt("điểm vật lý");
let hh = +prompt("điểm hóa học");
let sh = +prompt("điẻm sinh học");
let tong = vl + hh + sh;
let tbm = (vl + hh + sh) / 3;
console.log(tong);
console.log(tbm);
