alert("xin chào");
