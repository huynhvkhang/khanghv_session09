let width = +prompt("nhập chiều rộng");
let height = +prompt("nhập chiều dài");
console.log(width * height);
