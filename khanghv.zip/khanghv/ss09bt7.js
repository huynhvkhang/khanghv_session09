let l = +prompt("nhập chiều dài");
let w = +prompt("nhập chiều rộng");
let p = (l + w) * 2;
let s = l * w;
console.log(p);
console.log(s);
