let a = 6;
let result = ++a + a + a++ + ++a + a;
console.log(a);
