let r = +prompt("nhập bán kính hình tròn");
let p = r * 2 * 3.14;
let s = 3.14 * r ** 2;
console.log(p);
console.log(s);
