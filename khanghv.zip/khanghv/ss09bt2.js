let i = 10;
let f = 20.5;
let b = "true";
let s = "Hà Nội";
console.log(i);
console.log(f);
console.log(b);
console.log(s);
