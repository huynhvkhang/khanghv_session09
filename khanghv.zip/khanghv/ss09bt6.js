let c = +prompt("nhập giá trị Celsius");
console.log(c * (9 / 5) + 32);
