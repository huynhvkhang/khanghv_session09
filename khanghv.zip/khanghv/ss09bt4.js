confirm("Bạn đã đủ 18 tuổi chưa? ");
